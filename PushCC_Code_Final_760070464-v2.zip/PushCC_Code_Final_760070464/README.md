# Push-Compare-and-Confirm (PushCC) Research Reproduction — ECMM463

**Author:** Nitesh Pal (Student ID: 760070464) — Individual Submission (100%; AI-Assisted Coursework)
**Module:** ECMM463 — Building Secure and Trustworthy Systems (University of Exeter, 2026/27)
**Repository:** https://github.com/ntshpal286-max/ecmm463-pushcc

Faithful reproduction and validation of:
> M. Jubur, N. Saxena, and F. A. Reegu, *"Usability and Security Analysis of the Compare-and-Confirm Method in Mobile Push-Based Two-Factor Authentication,"* IEEE Transactions on Mobile Computing, vol. 24, no. 6, pp. 4623–4638, June 2025. https://doi.org/10.1109/TMC.2024.3524093

*(For a quick plain-text execution guide that opens directly in Notepad/TextEdit, see `HOW_TO_RUN.txt`.)*

## What This Package Reproduces

1. **Full 3-Phase Study Protocol (Section III.E, Fig. 5)**
   - **Phase I (Study Primer):** Instructions, demo account creation, and linking of the simulated `Push2FA_Compare` authenticator app.
   - **Phase II-A (Practice Trials):** 4 strictly benign trials (PC 4-char, PC 6-char, Phone 4-char, Phone 6-char), excluded from final analysis.
   - **Phase II-B (24 Main Study Trials):** Balanced 2 (PC / Phone) x 2 (Benign / Attack) x 2 (4-char / 6-char) x 3 repeats, randomized via `crypto.getRandomValues`.
   - **Phase III (Post-Study Questionnaire):** Demographics, prior 2FA experience, and study-specific questions (Sections III.E & IV.D).
   - **5-Trial Live Demo Mode:** Condensed showcase (3 Benign, 2 Attack) for the 10-minute presentation slot.
2. **Paper-Faithful UI, Attack Model, and Timing (Figs. 1, 3, 4; Sections II.A & III.D)**
   - Dark browser terminal (`Welcome — You need to approve request [CODE] on your App`) and dark Android `Push2FA_Compare` UI with top push notification banner and green `APPROVE` / red `DENY` buttons.
   - First-factor login submit step so response timing starts at credential submission and ends on `APPROVE`/`DENY` (Section III.D).
   - Independent concurrency attack code generation (Fig. 4: `L1BO` vs `JX0E`), plus an optional toggle for 1-character near-match attacks.
   - 30-second push timeout and dismiss/ignore option; unanswered notifications are excluded from TPR/FPR denominators.
3. **Statistical Analysis Pipeline (`analyze_results.py`, Sections III.D & IV)**
   - Computes TPR, FPR, Mean/SD response time, and 0–5 User Consistency Scores against published benchmarks from Jubur et al. (2025).
   - Runs all 12 pairwise Wilcoxon Signed-Rank Tests (WSRT) with Bonferroni correction (`alpha = 0.0042`) and effect size `r = |Z| / sqrt(N)`.
   - Fits the Linear Mixed-Effects Model (`RT ~ Device + CodeLength + SessionType + (1 | ParticipantID)`).
   - Generates `results_comparison.png`.

## Prerequisites & Required Libraries

- **Browser Simulator:** Any modern desktop browser (Chrome, Edge, Firefox, Safari) — **zero installation**, runs fully offline.
- **Python Suite:** Python **3.10+** with the libraries listed in `requirements.txt`:
  - `numpy>=1.24`
  - `pandas>=2.0`
  - `scipy>=1.10`
  - `statsmodels>=0.14`
  - `matplotlib>=3.6`

## How to Run

### 1. Offline Browser Simulator (Zero Installation)
1. Extract this ZIP archive (or run `git clone https://github.com/ntshpal286-max/ecmm463-pushcc.git`).
2. Double-click `pushcc_study_simulator.html` to open it in Chrome, Edge, Firefox, or Safari.
3. Select **Start 5-Trial Live Demo** (for presentation demo) or **Start Full 3-Phase Study** (for full 24-trial protocol + survey).
4. Export results via **Download Trials CSV** (and **Download Questionnaire CSV**).

### 2. Install Python Dependencies
Run inside the extracted `PushCC_Code_Final_760070464` directory:
```bash
pip install -r requirements.txt
```

### 3. Automated Verification Suite
```bash
python verify_simulator.py
```
Expected result: `ALL VERIFICATION CHECKS PASSED.` (verifies 103 DOM IDs, schedules, 32/32 five-trial paths, timeout exclusion, and end-to-end execution of `analyze_results.py`).

### 4. Statistical Analysis Pipeline
```bash
# Analyze the included 24-trial P01 self-run export (n=1 validation):
python analyze_results.py pushcc_P01_24trials.csv

# Analyze the 5-trial demo schema example (or your newly exported CSV):
python analyze_results.py sample_demo_trials.csv

# Validate the full 12x WSRT + Bonferroni + MixedLM pipeline on a 20-participant synthetic cohort:
python analyze_results.py --validate-pipeline
```
Each command prints the full benchmark comparison table and saves `results_comparison.png`.

## File Manifest (8 Files)
- `HOW_TO_RUN.txt` — Plain-text step-by-step run instructions and library prerequisites (opens directly in Notepad/TextEdit).
- `README.md` — Markdown architecture overview and run instructions.
- `requirements.txt` — Python dependencies (`numpy`, `pandas`, `scipy`, `statsmodels`, `matplotlib`).
- `pushcc_study_simulator.html` — Standalone offline browser reproduction of the PushCC study.
- `analyze_results.py` — Statistical replication script (TPR/FPR, 0–5 consistency, 12x WSRT + Bonferroni, MixedLM, comparison chart).
- `verify_simulator.py` — Automated verification of 103 DOM ID bindings, schedules, 32 five-trial paths, timeout exclusion, and analysis execution.
- `pushcc_P01_24trials.csv` — Completed 24-trial individual self-run export (`n=1`: 100% TPR, 0% FPR, overall mean RT 5.31 s, 0 timeouts).
- `sample_demo_trials.csv` — Illustrative 5-trial live demo schema example.
