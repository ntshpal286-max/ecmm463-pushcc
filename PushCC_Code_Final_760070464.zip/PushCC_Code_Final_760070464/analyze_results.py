"""
Statistical analysis script reproducing the evaluation methodology of:
Jubur, Saxena & Reegu (2025), "Usability and Security Analysis of the
Compare-and-Confirm Method in Mobile Push-Based Two-Factor Authentication,"
IEEE Transactions on Mobile Computing, 24(6), 4623-4638.
DOI: 10.1109/TMC.2024.3524093

Usage:
    python analyze_results.py pushcc_P01_trials.csv [pushcc_P02_trials.csv ...]
    python analyze_results.py --validate-pipeline
"""

import argparse
import math
import sys
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon, norm
import statsmodels.formula.api as smf

# Published benchmarks from Jubur, Saxena & Reegu (2025), Figs. 6-8 & Sec. IV-V
PAPER_BENCHMARKS = {
    "overall": {"tpr": 97.12, "fpr": 49.56, "rt_benign": 8.08, "rt_attack": 8.08},
    "PC":      {"tpr": 98.48, "fpr": 49.77, "rt_benign": 8.15, "rt_attack": 9.09, "cons_b": 4.5, "cons_a": 2.5},
    "Phone":   {"tpr": 95.76, "fpr": 49.36, "rt_benign": 8.01, "rt_attack": 7.08, "cons_b": 4.7, "cons_a": 1.8},
    ("PC", 4):    {"tpr": 99.51, "fpr": 49.54, "rt_benign": 7.91, "rt_attack": 9.21},
    ("PC", 6):    {"tpr": 97.55, "fpr": 50.23, "rt_benign": 8.38, "rt_attack": 8.97},
    ("Phone", 4): {"tpr": 94.98, "fpr": 48.83, "rt_benign": 7.79, "rt_attack": 7.09},
    ("Phone", 6): {"tpr": 96.81, "fpr": 49.88, "rt_benign": 8.22, "rt_attack": 7.06},
}

BONFERRONI_COMPARISONS = 12
BONFERRONI_ALPHA = 0.05 / BONFERRONI_COMPARISONS  # 0.0042


def generate_pipeline_validation_data(n_participants=20, seed=42):
    """
    Generate a clearly labeled SYNTHETIC dataset solely to verify that the
    WSRT + Bonferroni + Mixed-Effects statistical pipeline executes cleanly.
    Not real human participant data.
    """
    rng = np.random.default_rng(seed)
    rows = []
    for p in range(1, n_participants + 1):
        pid = f"SYN_{p:02d}"
        p_offset = rng.normal(0.0, 2.2)  # random participant intercept
        trial_num = 0
        for setting in ["PC", "Phone"]:
            for session_type in ["Benign", "Attack"]:
                for code_length in [4, 6]:
                    for _ in range(3):
                        trial_num += 1
                        base_rt = 8.4 if setting == "PC" else 7.4
                        if code_length == 6:
                            base_rt += 0.25
                        rt = max(1.2, base_rt + p_offset + rng.normal(0, 1.5))
                        if session_type == "Benign":
                            p_approve = 0.98 if setting == "PC" else 0.96
                        else:
                            p_approve = 0.50
                        approved = rng.random() < p_approve
                        action = "Approved" if approved else "Denied"
                        outcome = (
                            ("TP" if approved else "FN")
                            if session_type == "Benign"
                            else ("FP" if approved else "TN")
                        )
                        rows.append({
                            "participant_id": pid,
                            "phase": "Main",
                            "trial": trial_num,
                            "setting": setting,
                            "code_length": code_length,
                            "session_type": session_type,
                            "attack_model": "concurrency" if session_type == "Attack" else "none",
                            "terminal_code": "SYN4" if code_length == 4 else "SYN600",
                            "notification_code": (
                                ("SYN4" if code_length == 4 else "SYN600")
                                if session_type == "Benign"
                                else ("ATK4" if code_length == 4 else "ATK600")
                            ),
                            "user_action": action,
                            "outcome": outcome,
                            "correct": str(outcome in ("TP", "TN")),
                            "response_time_seconds": round(rt, 3),
                            "app_switches": int(setting == "Phone"),
                        })
    return pd.DataFrame(rows)


def wilcoxon_with_effect_size(x, y):
    """Run Wilcoxon Signed-Rank Test and compute r = Z / sqrt(N)."""
    diffs = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    valid = ~np.isnan(diffs)
    diffs = diffs[valid]
    n = len(diffs)
    if n < 3 or np.allclose(diffs, 0):
        return np.nan, np.nan, np.nan, n
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        stat, p_val = wilcoxon(diffs, zero_method="wilcox")
    # Convert two-sided p-value to approximate |Z| for effect size r = |Z| / sqrt(N)
    p_clipped = min(max(p_val, 1e-15), 1.0)
    z_abs = abs(norm.isf(p_clipped / 2.0))
    r_eff = z_abs / math.sqrt(n)
    return stat, p_val, r_eff, n


def summarize_dataset(df, label="Observed", out_plot=Path("results_comparison.png")):
    # Exclude Practice trials and Unanswered notifications (Section III.D & III.E)
    if "phase" in df.columns:
        df = df[df["phase"] != "Practice"].copy()
    total_rows = len(df)
    answered = df[df["outcome"] != "Unanswered"].copy()
    unanswered_count = total_rows - len(answered)
    answered["response_time_seconds"] = pd.to_numeric(answered["response_time_seconds"], errors="coerce")
    answered["code_length"] = pd.to_numeric(answered["code_length"], errors="coerce").astype(int)

    n_participants = answered["participant_id"].nunique()
    print("=" * 76)
    print(f"Push-Compare-and-Confirm Analysis ({label})")
    print(f"Participants: {n_participants} | Answered trials: {len(answered)} | Excluded unanswered: {unanswered_count}")
    print("=" * 76)

    # 1. Overall TPR / FPR / RT
    benign = answered[answered["session_type"] == "Benign"]
    attack = answered[answered["session_type"] == "Attack"]
    tpr = 100.0 * (benign["outcome"] == "TP").mean() if len(benign) else np.nan
    fpr = 100.0 * (attack["outcome"] == "FP").mean() if len(attack) else np.nan
    rt_b_m, rt_b_sd = benign["response_time_seconds"].mean(), benign["response_time_seconds"].std()
    rt_a_m, rt_a_sd = attack["response_time_seconds"].mean(), attack["response_time_seconds"].std()

    print("\n1. Overall Metrics vs. Jubur, Saxena & Reegu (2025)")
    print(f"  Overall TPR (Benign): {tpr:6.2f}%   (Paper: {PAPER_BENCHMARKS['overall']['tpr']:.2f}%)")
    print(f"  Overall FPR (Attack): {fpr:6.2f}%   (Paper: {PAPER_BENCHMARKS['overall']['fpr']:.2f}%)")
    print(f"  Benign RT mean (SD):  {rt_b_m:6.2f} s ({rt_b_sd:.2f})  (Paper: 8.08 s (4.80))")
    print(f"  Attack RT mean (SD):  {rt_a_m:6.2f} s ({rt_a_sd:.2f})  (Paper: 8.08 s (5.72))")

    # 2. Cell-by-cell breakdown (Device x Code Length)
    print("\n2. Condition Breakdown (Device x Code Length)")
    rows = []
    for setting in ["PC", "Phone"]:
        for length in [4, 6]:
            sub = answered[(answered["setting"] == setting) & (answered["code_length"] == length)]
            b_sub = sub[sub["session_type"] == "Benign"]
            a_sub = sub[sub["session_type"] == "Attack"]
            c_tpr = 100.0 * (b_sub["outcome"] == "TP").mean() if len(b_sub) else np.nan
            c_fpr = 100.0 * (a_sub["outcome"] == "FP").mean() if len(a_sub) else np.nan
            c_rt_b = b_sub["response_time_seconds"].mean() if len(b_sub) else np.nan
            c_rt_a = a_sub["response_time_seconds"].mean() if len(a_sub) else np.nan
            ref = PAPER_BENCHMARKS[(setting, length)]
            rows.append({
                "Condition": f"{setting} {length}-char",
                "Obs_TPR%": round(c_tpr, 2) if not np.isnan(c_tpr) else np.nan,
                "Paper_TPR%": ref["tpr"],
                "Obs_FPR%": round(c_fpr, 2) if not np.isnan(c_fpr) else np.nan,
                "Paper_FPR%": ref["fpr"],
                "Obs_RT_Benign": round(c_rt_b, 2) if not np.isnan(c_rt_b) else np.nan,
                "Paper_RT_Benign": ref["rt_benign"],
                "Obs_RT_Attack": round(c_rt_a, 2) if not np.isnan(c_rt_a) else np.nan,
                "Paper_RT_Attack": ref["rt_attack"],
            })
    summary_df = pd.DataFrame(rows)
    print(summary_df.to_string(index=False))

    # 3. User Consistency Rate (0-5 scale, Section III.D & V.A)
    print("\n3. User Consistency Score (0-5 Scale)")
    for setting in ["PC", "Phone"]:
        sub = answered[answered["setting"] == setting]
        b_sub = sub[sub["session_type"] == "Benign"]
        a_sub = sub[sub["session_type"] == "Attack"]
        b_cons = 5.0 * (b_sub["outcome"] == "TP").mean() if len(b_sub) else np.nan
        a_cons = 5.0 * (a_sub["outcome"] == "TN").mean() if len(a_sub) else np.nan
        ref = PAPER_BENCHMARKS[setting]
        print(f"  {setting:5s} | Benign: {b_cons:4.2f}/5 (Paper: {ref['cons_b']}/5) | Attack: {a_cons:4.2f}/5 (Paper: {ref['cons_a']}/5)")

    # 4. Statistical Tests (WSRT + Bonferroni + Mixed-Effects Model) when N >= 3 participants
    if n_participants >= 3:
        print(f"\n4. 12 Pairwise Wilcoxon Signed-Rank Tests on Response Time (Bonferroni alpha = {BONFERRONI_ALPHA:.4f})")
        piv = answered.pivot_table(
            index="participant_id",
            columns=["setting", "session_type", "code_length"],
            values="response_time_seconds",
            aggfunc="mean",
        )
        comparisons = [
            # 4 Device comparisons
            ("PC vs Phone (Benign, 4-char)", ("PC", "Benign", 4), ("Phone", "Benign", 4)),
            ("PC vs Phone (Benign, 6-char)", ("PC", "Benign", 6), ("Phone", "Benign", 6)),
            ("PC vs Phone (Attack, 4-char)", ("PC", "Attack", 4), ("Phone", "Attack", 4)),
            ("PC vs Phone (Attack, 6-char)", ("PC", "Attack", 6), ("Phone", "Attack", 6)),
            # 4 Code-length comparisons
            ("4 vs 6 char (PC, Benign)",     ("PC", "Benign", 4), ("PC", "Benign", 6)),
            ("4 vs 6 char (PC, Attack)",     ("PC", "Attack", 4), ("PC", "Attack", 6)),
            ("4 vs 6 char (Phone, Benign)",  ("Phone", "Benign", 4), ("Phone", "Benign", 6)),
            ("4 vs 6 char (Phone, Attack)",  ("Phone", "Attack", 4), ("Phone", "Attack", 6)),
            # 4 Session-type comparisons
            ("Benign vs Attack (PC, 4-char)",    ("PC", "Benign", 4), ("PC", "Attack", 4)),
            ("Benign vs Attack (PC, 6-char)",    ("PC", "Benign", 6), ("PC", "Attack", 6)),
            ("Benign vs Attack (Phone, 4-char)", ("Phone", "Benign", 4), ("Phone", "Attack", 4)),
            ("Benign vs Attack (Phone, 6-char)", ("Phone", "Benign", 6), ("Phone", "Attack", 6)),
        ]
        wsrt_rows = []
        for name, c1, c2 in comparisons:
            if c1 in piv.columns and c2 in piv.columns:
                stat, p_val, r_eff, n_obs = wilcoxon_with_effect_size(piv[c1], piv[c2])
                sig = "Yes" if (not np.isnan(p_val) and p_val < BONFERRONI_ALPHA) else "No"
                wsrt_rows.append({
                    "Comparison": name, "N": n_obs,
                    "p_value": round(p_val, 4) if not np.isnan(p_val) else np.nan,
                    "effect_r": round(r_eff, 3) if not np.isnan(r_eff) else np.nan,
                    "Sig_Bonf": sig,
                })
        if wsrt_rows:
            print(pd.DataFrame(wsrt_rows).to_string(index=False))

        print("\n5. Linear Mixed-Effects Model (Section IV.A: RT ~ Device + CodeLength + SessionType + (1|Participant))")
        try:
            model_df = answered.copy()
            model_df["is_phone"] = (model_df["setting"] == "Phone").astype(int)
            model_df["is_6char"] = (model_df["code_length"] == 6).astype(int)
            model_df["is_benign"] = (model_df["session_type"] == "Benign").astype(int)
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                md = smf.mixedlm(
                    "response_time_seconds ~ is_phone + is_6char + is_benign",
                    data=model_df,
                    groups=model_df["participant_id"],
                )
                mdf = md.fit(reml=True)
            for term, nice in [
                ("Intercept", "Intercept (PC, 4-char, Attack)"),
                ("is_phone", "Device: Phone vs PC (Paper beta=-1.078, p=0.004)"),
                ("is_6char", "Code Length: 6 vs 4 (Paper beta=+0.161, p=0.669)"),
                ("is_benign", "Session: Benign vs Attack (Paper beta=-0.006, p=0.986)"),
            ]:
                print(
                    f"  {nice:56s} | beta={mdf.fe_params[term]:+6.3f}, "
                    f"SE={mdf.bse[term]:.3f}, z={mdf.tvalues[term]:+6.2f}, p={mdf.pvalues[term]:.4f}"
                )
            print(f"  Random intercept variance (Participant ID): {float(mdf.cov_re.iloc[0, 0]):.3f} (Paper: 7.452)")
        except Exception as exc:
            print(f"  Mixed-effects model skipped: {exc}")
    else:
        print("\n4-5. WSRT & Mixed-Effects Model require >= 3 participants (currently "
              f"{n_participants}). Export CSVs from multiple participants or run --validate-pipeline.")

    # 6. Comparison Plot
    fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.4), dpi=160)
    conds = summary_df["Condition"].tolist()
    x = np.arange(len(conds))
    w = 0.2

    # Panel A: TPR and FPR vs Paper
    ax = axes[0]
    ax.bar(x - 1.5*w, summary_df["Obs_TPR%"].fillna(0), w, label="Local TPR", color="#1d4ed8")
    ax.bar(x - 0.5*w, summary_df["Paper_TPR%"], w, label="Paper TPR (n=65)", color="#93c5fd")
    ax.bar(x + 0.5*w, summary_df["Obs_FPR%"].fillna(0), w, label="Local FPR", color="#b91c1c")
    ax.bar(x + 1.5*w, summary_df["Paper_FPR%"], w, label="Paper FPR (n=65)", color="#fca5a5")
    ax.set_xticks(x)
    ax.set_xticklabels(conds, fontsize=8.5)
    ax.set_ylim(0, 124)
    ax.set_ylabel("Approval Rate (%)")
    ax.set_title("TPR (Benign) & FPR (Attack) vs. Jubur et al. (2025)", fontweight="bold", fontsize=10)
    ax.legend(fontsize=7.5, ncol=2, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    # Panel B: Response Times vs Paper
    ax = axes[1]
    ax.bar(x - 1.5*w, summary_df["Obs_RT_Benign"].fillna(0), w, label="Local Benign RT", color="#0f766e")
    ax.bar(x - 0.5*w, summary_df["Paper_RT_Benign"], w, label="Paper Benign RT", color="#99f6e4")
    ax.bar(x + 0.5*w, summary_df["Obs_RT_Attack"].fillna(0), w, label="Local Attack RT", color="#d97706")
    ax.bar(x + 1.5*w, summary_df["Paper_RT_Attack"], w, label="Paper Attack RT", color="#fde68a")
    ax.set_xticks(x)
    ax.set_xticklabels(conds, fontsize=8.5)
    max_rt = max(10.0, float(np.nanmax(summary_df[["Obs_RT_Benign","Paper_RT_Benign","Obs_RT_Attack","Paper_RT_Attack"]].to_numpy())))
    ax.set_ylim(0, max_rt * 1.28)
    ax.set_ylabel("Mean Response Time (seconds)")
    ax.set_title("Authentication Response Time vs. Jubur et al. (2025)", fontweight="bold", fontsize=10)
    ax.legend(fontsize=7.5, ncol=2, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.02))
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)

    fig.tight_layout()
    fig.savefig(out_plot, dpi=180, bbox_inches="tight")
    plt.close(fig)
    print(f"\nSaved comparison chart to: {out_plot}")


def main():
    parser = argparse.ArgumentParser(description="Analyze PushCC simulator CSV exports.")
    parser.add_argument("csv_files", nargs="*", help="One or more exported pushcc_*_trials.csv files")
    parser.add_argument(
        "--validate-pipeline",
        action="store_true",
        help="Run statistical pipeline on a clearly labeled 20-participant synthetic validation set.",
    )
    parser.add_argument("--out-plot", default="results_comparison.png", help="Output chart PNG path")
    args = parser.parse_args()

    if args.validate_pipeline:
        df = generate_pipeline_validation_data(n_participants=20, seed=42)
        summarize_dataset(df, label="Synthetic Validation Cohort (n=20)", out_plot=Path(args.out_plot))
        return

    if not args.csv_files:
        print("Error: Provide one or more exported trial CSV files, or pass --validate-pipeline.")
        sys.exit(1)

    frames = [pd.read_csv(f) for f in args.csv_files]
    df = pd.concat(frames, ignore_index=True)
    summarize_dataset(df, label="Observed Export", out_plot=Path(args.out_plot))


if __name__ == "__main__":
    main()
