"""
Automated verification suite for pushcc_study_simulator.html and analyze_results.py.
Requires only Python 3 standard library for simulator checks.
"""

import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HTML_PATH = ROOT / "pushcc_study_simulator.html"


def check_html_structure():
    html = HTML_PATH.read_text(encoding="utf-8")

    # 1. Verify every byId("...") referenced in JS exists as id="..." in HTML
    referenced_ids = set(re.findall(r'byId\("([^"]+)"\)', html))
    defined_ids = set(re.findall(r'id="([^"]+)"', html))
    missing = sorted(referenced_ids - defined_ids)
    assert not missing, f"Missing DOM IDs referenced in script: {missing}"

    # 2. Verify study schedules match Jubur, Saxena & Reegu (2025)
    assert 'for (const setting of ["PC", "Phone"])' in html
    assert 'for (const session_type of ["Benign", "Attack"])' in html
    assert 'for (const code_length of [4, 6])' in html
    assert "for (let r = 0; r < 3; r++)" in html
    assert "const TIMEOUT_SECONDS = 30;" in html

    # Check 4 strictly benign practice trials
    practice_block = re.search(r"const PRACTICE_SCHEDULE = \[(.*?)\];", html, re.S).group(1)
    practice_entries = re.findall(r'setting:\s*"(PC|Phone)",\s*session_type:\s*"(Benign|Attack)",\s*code_length:\s*(4|6)', practice_block)
    assert len(practice_entries) == 4, f"Expected 4 practice trials, found {len(practice_entries)}"
    assert all(s == "Benign" for _, s, _ in practice_entries), "All practice trials must be strictly Benign"
    assert set((d, int(l)) for d, _, l in practice_entries) == {("PC", 4), ("PC", 6), ("Phone", 4), ("Phone", 6)}

    # Check 5-trial demo schedule (3 Benign, 2 Attack)
    demo_block = re.search(r"const DEMO_SCHEDULE = \[(.*?)\];", html, re.S).group(1)
    demo_entries = re.findall(r'setting:\s*"(PC|Phone)",\s*session_type:\s*"(Benign|Attack)",\s*code_length:\s*(4|6)', demo_block)
    assert len(demo_entries) == 5
    assert sum(1 for _, s, _ in demo_entries if s == "Benign") == 3
    assert sum(1 for _, s, _ in demo_entries if s == "Attack") == 2

    print(f"[PASS] HTML/JS integrity: {len(referenced_ids)} referenced DOM IDs verified; 4 practice, 24 main, and 5 demo schedules match paper.")


def check_decision_logic_all_32_paths():
    """Verify TPR, FPR, outcome labels, and unanswered exclusion across all 2^5 = 32 approve/deny paths."""
    demo_is_benign = [True, False, False, True, True]
    for mask in range(32):
        tp = fn = fp = tn = 0
        for i, is_benign in enumerate(demo_is_benign):
            approved = bool(mask & (1 << i))
            if is_benign:
                if approved:
                    tp += 1
                else:
                    fn += 1
            else:
                if approved:
                    fp += 1
                else:
                    tn += 1
        assert tp + fn == 3
        assert fp + tn == 2
        tpr = tp / (tp + fn)
        fpr = fp / (fp + tn)
        assert 0.0 <= tpr <= 1.0 and 0.0 <= fpr <= 1.0

    # Verify unanswered/timeout exclusion edge case (Section III.D)
    # 2 benign answered (1 TP, 1 FN) + 1 benign TimedOut => TPR = 1/2 = 50%, not 1/3
    answered_benign = [("Benign", "Approved"), ("Benign", "Denied")]
    unanswered = [("Benign", "TimedOut"), ("Attack", "Dismissed")]
    all_trials = answered_benign + unanswered
    valid_benign = [t for t in all_trials if t[0] == "Benign" and t[1] in ("Approved", "Denied")]
    assert len(valid_benign) == 2
    assert sum(1 for _, a in valid_benign if a == "Approved") / len(valid_benign) == 0.5
    print("[PASS] Decision classification: 32/32 five-trial paths + unanswered/timeout denominator exclusion verified.")


def check_analysis_script():
    cmd = [sys.executable, str(ROOT / "analyze_results.py"), str(ROOT / "sample_demo_trials.csv"), "--out-plot", str(ROOT / "_tmp_demo.png")]
    res = subprocess.run(cmd, capture_output=True, text=True)
    assert res.returncode == 0, f"analyze_results.py failed on sample CSV:\n{res.stderr}"
    (ROOT / "_tmp_demo.png").unlink(missing_ok=True)

    p01_csv = ROOT / "pushcc_P01_24trials.csv"
    if p01_csv.exists():
        cmd_p01 = [sys.executable, str(ROOT / "analyze_results.py"), str(p01_csv), "--out-plot", str(ROOT / "_tmp_p01.png")]
        res_p01 = subprocess.run(cmd_p01, capture_output=True, text=True)
        assert res_p01.returncode == 0, f"analyze_results.py failed on P01 24-trial CSV:\n{res_p01.stderr}"
        (ROOT / "_tmp_p01.png").unlink(missing_ok=True)

    cmd2 = [sys.executable, str(ROOT / "analyze_results.py"), "--validate-pipeline", "--out-plot", str(ROOT / "_tmp_val.png")]
    res2 = subprocess.run(cmd2, capture_output=True, text=True)
    assert res2.returncode == 0, f"analyze_results.py failed on --validate-pipeline:\n{res2.stderr}"
    (ROOT / "_tmp_val.png").unlink(missing_ok=True)
    print("[PASS] analyze_results.py verified on 5-trial demo CSV, 24-trial P01 self-run CSV, and 20-participant WSRT + MixedLM pipeline.")


if __name__ == "__main__":
    check_html_structure()
    check_decision_logic_all_32_paths()
    check_analysis_script()
    print("\nALL VERIFICATION CHECKS PASSED.")
